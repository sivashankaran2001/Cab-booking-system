package Project.Cab_Booking_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Project.Cab_Booking_System.Model.Booking;
import Project.Cab_Booking_System.Model.CarDetails;
import Project.Cab_Booking_System.Repository.BookingRepo;
import Project.Cab_Booking_System.Service.BookingService;

@RestController
public class BookingController {
	
	@Autowired
	BookingService service;
	
	@Autowired
	BookingRepo bookingrepo;
	
	@PostMapping("/booking")
	public Booking reserveTable(@RequestBody Booking table) throws Exception {
		Booking obj = null;
		obj = service.savebooking(table);
		return obj;
	}
	
	@GetMapping("/bookingList")
	public List<Booking> getBookings() {
		return bookingrepo.findAll();
	}
}
