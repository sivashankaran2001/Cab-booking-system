package Project.Cab_Booking_System.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Project.Cab_Booking_System.Model.UserRegistration;
import Project.Cab_Booking_System.Repository.RegistrationRepo;
import Project.Cab_Booking_System.Service.RegistrationService;

@RestController
public class RegistrationController {
	
	@Autowired
	private RegistrationService service;
	
	@Autowired
	private RegistrationRepo registrationRepo;
	
	@PostMapping("/registeruser")
	@CrossOrigin(origins = "http://localhost:8082")
	public UserRegistration registerUser(@RequestBody UserRegistration user) throws Exception {
		String tempEmailid = user.getEmail();
		if(tempEmailid != null && !"".equals(tempEmailid)) {
			UserRegistration userobj = service.fetchUserByEmailId(tempEmailid);
			if(userobj != null) {
				throw new Exception("user with " + tempEmailid +"is already exist");
			}
		}
		UserRegistration userObj = null;
		userObj = service.saveuser(user);
		return userObj;
	}
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:8082")
	public UserRegistration loginUser(@RequestBody UserRegistration user) throws Exception {
		String tempEmailid = user.getEmail();
		String tempPass = user.getPassword();
		UserRegistration userobj = null;
		if(tempEmailid != null && tempPass != null) {
			userobj = service.fetchUserByEmailIdAndPassword(tempEmailid, tempPass);
		}
		if(userobj == null) {
			throw new Exception("User doesn't exist");
		}
		return null;
	}
	
	@GetMapping("/get")
	@CrossOrigin(origins = "http://localhost:8082")
	public List<UserRegistration> getUsers() {
		return registrationRepo.findAll();
	}
	
	@DeleteMapping(path = { "/{id}" })
	@CrossOrigin(origins = "http://localhost:8082")
	public UserRegistration deleteUser(@PathVariable("id") int id) {
		UserRegistration user = registrationRepo.getOne((id));
		registrationRepo.deleteById(id);
		return user;
	}

}
