//POJO class for the table booking.
package Project.Cab_Booking_System.Model;

import javax.persistence.*;

@Entity
public class Booking {

//fields for the table booking.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bookingId;
	
	@Column(name = "car_id")
	private Integer carId;
	
	@Column(name = "booking_date")
	private String bookingDate;
	
	@Column(name = "passenger_mobile")
	private String passenger_MobileNumber;
	
//Default constructor for this class.
	public Booking() {
		
	}
	
//Parameterized constructor for this class.
	public Booking(Integer bookingId, Integer carId, String bookingDate, String passenger_MobileNumber) {
		super();
		this.bookingId = bookingId;
		this.carId = carId;
		this.bookingDate = bookingDate;
		this.passenger_MobileNumber = passenger_MobileNumber;
	}

//Setters and Getters for the fields.
	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public Integer getCarId() {
		return carId;
	}

	public void setCarId(Integer carId) {
		this.carId = carId;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getPassenger_MobileNumber() {
		return passenger_MobileNumber;
	}

	public void setPassenger_MobileNumber(String passenger_MobileNumber) {
		this.passenger_MobileNumber = passenger_MobileNumber;
	}
	
	
}
