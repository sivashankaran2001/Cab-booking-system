package Project.Cab_Booking_System.Model; 

import javax.persistence.*; 

@Entity
public class CarDetails { 
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer carId; 
	
	@Column(name = "car_number")
	private String carNumber;
	
	@Column(name = "car_rating")
	private Integer rating;
	
	@Column(name = "car_payamount")
	private Double payamount;

	public Integer getCarId() {
		return carId;
	}

	public void setCarId(Integer carId) {
		this.carId = carId;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Double getPayamount() {
		return payamount;
	}

	public void setPayamount(Double payamount) {
		this.payamount = payamount;
	}

	public CarDetails() {
		
	}
	/**
	 * @param carId
	 * @param carNumber
	 * @param rating
	 * @param payamount
	 */
	public CarDetails(Integer carId, String carNumber, Integer rating, Double payamount) {
		super();
		this.carId = carId;
		this.carNumber = carNumber;
		this.rating = rating;
		this.payamount = payamount;
	}
	
	
}