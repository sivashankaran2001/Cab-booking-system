//POJO class for the driver table.
package Project.Cab_Booking_System.Model;

import javax.persistence.*;

@Entity
@Table(name = "driver")
public class Driver {

//Fields for the driver table.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name =  "driver_name")
	private String name;
	
	@Column(name = "driver_email")
	private String email;
	
	@Column(name = "driver_phonenumber")
	private Long phoneNumber;
	
	@Column(name = "driver_experience")
	private Integer experience;
	
	@Column(name = "driver_license")
	private String license;

//Getter and Setters.
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public String getLicense() {
		return license;
	}

	public void setLicense(String license) {
		this.license = license;
	}
	
//Default constructor for this POJO class.
	public Driver() {
		
	}

//Parameterized constructor for this POJO class.
	public Driver(Integer id, String name, String email, Long phoneNumber, Integer experience, String license) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.experience = experience;
		this.license = license;
	}
	
	
}
