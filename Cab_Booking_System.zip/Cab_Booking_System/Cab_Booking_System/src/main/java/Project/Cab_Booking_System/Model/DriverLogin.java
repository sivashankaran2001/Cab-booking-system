//POJO class for the table driver login table.
package Project.Cab_Booking_System.Model;

import javax.persistence.*;

@Entity
@Table(name = "driverlogin")
public class DriverLogin {

//Variable for the class DriverLogin.
	@Column(name = "driverlogin_name")
	private String name;
	
	@Column(name = "driverlogin_username")
	private String username;
	
	@Column(name = "driverlogin_password")
	private String password;

//Default constructor for this class.
	public DriverLogin() {
		
	}
	
//Parameterized constructor for this class.
	public DriverLogin(String name, String username, String password) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
	}

//Setters and Getters for this class.
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
