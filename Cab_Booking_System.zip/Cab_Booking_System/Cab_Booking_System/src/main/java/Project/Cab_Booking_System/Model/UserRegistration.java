//POJO class for the table passenger.
package Project.Cab_Booking_System.Model;

import javax.persistence.*;

@Entity
@Table(name = "passenger")
public class UserRegistration {

//Fields for the passenger table.
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "passenger_name")
	private String name;
	
	@Column(name = "passenger_phonenumber")
	private Long phoneNumber;
	
	@Column(name = "passenger_email")
	private String email;
	
	@Column(name = "passenger_address")
	private String address;
	
	@Column(name = "passenger_dob")
	private String dob;

	@Column(name = "passenger_username")
	private String username;
	
	@Column(name = "passenger_password")
	private String password;
	

	//Default constructor for the table.
	public UserRegistration() {
		
	}
	
//Parameterized constructor for the table.
	public UserRegistration(Integer id, String name, Long phoneNumber, String email, String address, String dob) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.address = address;
		this.dob = dob;
	}

//Getters and Setters
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
