package Project.Cab_Booking_System.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Project.Cab_Booking_System.Model.Booking;

public interface BookingRepo extends JpaRepository<Booking, Integer> {

}
