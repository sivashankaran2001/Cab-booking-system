package Project.Cab_Booking_System.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Project.Cab_Booking_System.Model.UserRegistration;

public interface RegistrationRepo extends JpaRepository<UserRegistration,Integer> {

	public UserRegistration findByEmailId(String emailId);
	
	public UserRegistration findByEmailidAndPassword(String emailId,String password);
	
}
