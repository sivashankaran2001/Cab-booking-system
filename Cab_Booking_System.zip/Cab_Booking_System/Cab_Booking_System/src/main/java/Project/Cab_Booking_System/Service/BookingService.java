package Project.Cab_Booking_System.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Project.Cab_Booking_System.Model.Booking;
import Project.Cab_Booking_System.Model.UserRegistration;
import Project.Cab_Booking_System.Repository.BookingRepo;

@Service
public class BookingService {

	@Autowired
	BookingRepo bookrepo;
	
	public Booking savebooking(Booking tables) {
		return bookrepo.save(tables);
	}
}
