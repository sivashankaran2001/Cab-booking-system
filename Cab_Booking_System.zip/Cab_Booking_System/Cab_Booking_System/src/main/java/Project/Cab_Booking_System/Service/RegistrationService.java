package Project.Cab_Booking_System.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Project.Cab_Booking_System.Model.UserRegistration;
import Project.Cab_Booking_System.Repository.RegistrationRepo;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationRepo repo;
	
	public UserRegistration saveuser(UserRegistration user) {
		return repo.save(user);
	}
	
	public UserRegistration fetchUserByEmailId(String email) {
		return repo.findByEmailId(email);
	}
	
	public UserRegistration fetchUserByEmailIdAndPassword(String email, String password) {
		return repo.findByEmailidAndPassword(email,password);
	}
}
