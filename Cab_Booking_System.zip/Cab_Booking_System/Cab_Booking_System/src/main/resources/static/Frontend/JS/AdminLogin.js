  function validateUsername(){
    var username =  document.getElementById("username").value;
    var password = document.getElementById("password").value;

        if(username == "began.d@hcl.com" && password == "Arshiya123"){
                window.location.assign("AdminUsing.html");
                alert("Log in successfully...");
        }
        else {
            alert("Wrong input...");
            return;
        }
    }